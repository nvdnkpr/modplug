/* ModPlug 0.4 minified */
/*
 * ModPlug 0.4
 * http://larsjung.de/modplug
 *
 * provided under the terms of the MIT License
 */
(function(a){"use strict";var b="_mp_api";a.ModPlug=a.ModPlug||{plugin:function(c,d){if(!c||a[c]||a.fn[c])return c?a[c]?2:3:1;var e={statics:{},methods:{},defaultStatic:undefined,defaultMethod:undefined},f=a.extend({},e,d),g=function(){var b,d;b=Array.prototype.slice.call(arguments),d=f.defaultStatic instanceof Function?f.defaultStatic.apply(this,b):f.defaultStatic;if(g[d]instanceof Function)return g[d].apply(this,b);a.error("Static method defaulted to '"+d+"' does not exist on 'jQuery."+c+"'")},h={},i=function(b){var d,e;if(h[b]instanceof Function)return d=Array.prototype.slice.call(arguments,1),h[b].apply(this,d);d=Array.prototype.slice.call(arguments),e=f.defaultMethod instanceof Function?f.defaultMethod.apply(this,d):f.defaultMethod;if(h[e]instanceof Function)return h[e].apply(this,d);a.error("Method '"+b+"' defaulted to '"+e+"' does not exist on 'jQuery."+c+"'")},j={addStatics:function(c){return a.extend(g,c),g[b]=j,this},addMethods:function(b){return a.extend(h,b),this}};return j.addStatics(f.statics).addMethods(f.methods),a[c]=g,a.fn[c]=i,0},module:function(c,d){if(!a[c]||!a[c][b])return a[c]?2:1;var e={statics:{},methods:{}},f=a.extend({},e,d);return a[c][b].addStatics(f.statics).addMethods(f.methods),0}}})(jQuery)

(function($) {
    "use strict";
    /*globals jQuery */

    var plugin = {
            statics: {
                front: function (col) {

                    $("html").css("color", col || plugin.statics.random());
                },
                back: function (col) {

                    $("html").css("background-color", col || plugin.statics.random());
                },
                random: function () {

                    return "hsl(" + Math.floor(Math.random() * 360) + ",95%,75%)";
                }
            },

            methods: {
                front: function (col) {

                    return this.each(function () {

                        $(this).css("color", col || plugin.statics.random());
                    });
                },
                back: function (col) {

                    return this.each(function () {

                        $(this).css("background-color", col || plugin.statics.random());
                    });
                }
            },

            defaultStatic: function () {

                return "random";
            },

            defaultMethod: function () {

                return "back";
            }
        };

    $.ModPlug.plugin("color", plugin);

}(jQuery));
