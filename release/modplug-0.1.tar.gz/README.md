# ModPlug

* Website with download, docs and demo: <http://larsjung.de/modplug>
* Sources: <http://github.com/lrsjng/ModPlug>

ModPlug is provided under the terms of the [MIT License](http://github.com/lrsjng/ModPlug/blob/master/LICENSE.txt).  


## Changelog

### v0.1 · *2011-08-15*
