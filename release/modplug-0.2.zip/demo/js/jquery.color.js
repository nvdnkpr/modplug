/* ModPlug 0.2 minified */
(function(a){ModPlug=function(d){var f={namespace:undefined,statics:{},methods:{},defaultStatic:undefined,defaultMethod:undefined},e=a.extend({},f,d);if(e.namespace===undefined||a[e.namespace]!==undefined||a.fn[e.namespace]!==undefined){a.error("A plugin already exists on 'jQuery."+e.namespace+"'");return}var g={},c={},b=function(){var i=undefined;if(e.defaultStatic instanceof Function){i=e.defaultStatic(arguments);if(g[i] instanceof Function){return g[i].apply(this,arguments)}}a.error("Static method '"+i+"' does not exist on 'jQuery."+e.namespace+"'");return this},h=function(i){if(c[i] instanceof Function){return c[i].apply(this,Array.prototype.slice.call(arguments,1))}if(e.defaultMethod instanceof Function){i=e.defaultMethod(arguments);if(c[i] instanceof Function){return c[i].apply(this,arguments)}}a.error("Method '"+i+"' does not exist on 'jQuery."+e.namespace+"'");return this};this.addStatics=function(i){a.extend(g,i);a.extend(b,i);b.internal=this;return this};this.addMethods=function(i){a.extend(c,i);return this};this.addStatics(e.statics).addMethods(e.methods);a[e.namespace]=b;a.fn[e.namespace]=h};ModPlugModule=function(){var c={namespace:undefined,statics:{},methods:{}},b=a.extend({},c,options);if(!a[b.namespace]||!a[b.namespace].internal instanceof ModPlug){a.error("No ModPlug plugin exists on 'jQuery."+b.namespace+"'");return}a[b.namespace].internal.addStatics(b.statics).addMethods(b.methods)}})(jQuery);


( function( $ ) {

	var plugin = {

			namespace: "color",
	
			statics: {
	
				front: function ( col ) {
	
					$( "html" ).css( "color", col || plugin.statics.random() );
				},
	
				back: function ( col ) {
	
					$( "html" ).css( "background-color", col || plugin.statics.random() );
				},
	
				random: function () {
					
					return "hsl(" + Math.floor( Math.random() * 360 ) + ",95%,75%)";
				}
			},
	
			methods: {
	
				front: function ( col ) {
	
					return this.each( function () {
	
						$( this ).css( "color", col || plugin.statics.random() );
					} );
				},
	
				back: function ( col ) {
	
					return this.each( function () {
	
						$( this ).css( "background-color", col || plugin.statics.random() );
					} );
				}
			},
	
			defaultStatic: function () {
	
				return "random";
			},
	
			defaultMethod: function () {
	
				return "back";
			}
		};
	
	new ModPlug( plugin );

} )( jQuery );
