# ModPlug

* Website with download, docs and demo: <http://larsjung.de/modplug>
* Sources: <http://github.com/lrsjng/ModPlug>

ModPlug is provided under the terms of the [MIT License](http://github.com/lrsjng/ModPlug/blob/master/LICENSE.txt).


## Changelog

### v0.4 · *2011-08-25*

* refactored to make it more accepted by jsLint
* better compression


### v0.3 · *2011-08-22*

* fixed bug in default function applying
* syntax changes
* code cleaned


### v0.2 · *2011-08-19*

* cleaned and redesigned


### v0.1 · *2011-08-15*
