/* ModPlug 0.3 minified */
(function(b){var a=function(g,e){if(!g){b.error("No namespace specified.");return}else{if(b[g]||b.fn[g]){b.error("A plugin already exists on 'jQuery."+g+"'");return}}var h={statics:{},methods:{},defaultStatic:undefined,defaultMethod:undefined},f=b.extend({},h,e),c=function(){var j,k;j=Array.prototype.slice.call(arguments);k=f.defaultStatic instanceof Function?f.defaultStatic.apply(this,j):f.defaultStatic;if(c[k] instanceof Function){return c[k].apply(this,j)}b.error("Static method defaulted to '"+k+"' does not exist on 'jQuery."+g+"'")},d={},i=function(l){var j,k;if(d[l] instanceof Function){j=Array.prototype.slice.call(arguments,1);return d[l].apply(this,j)}j=Array.prototype.slice.call(arguments);k=f.defaultMethod instanceof Function?f.defaultMethod.apply(this,j):f.defaultMethod;if(d[k] instanceof Function){return d[k].apply(this,j)}b.error("Method '"+l+"' defaulted to '"+k+"' does not exist on 'jQuery."+g+"'")};this.addStatics=function(j){b.extend(c,j);c._modplug=this;return this};this.addMethods=function(j){b.extend(d,j);return this};this.addStatics(f.statics).addMethods(f.methods);b[g]=c;b.fn[g]=i};b.ModPlug=b.ModPlug||{plugin:function(d,c){new a(d,c)},module:function(e,c){if(!b[e]||!b[e]._modplug instanceof a){b.error("No ModPlug plugin exists on 'jQuery."+e+"'");return}var f={statics:{},methods:{}},d=b.extend({},f,c);b[e]._modplug.addStatics(d.statics).addMethods(d.methods)}}})(jQuery);


( function( $ ) {

	var plugin = {
			statics: {
				front: function ( col ) {
	
					$( "html" ).css( "color", col || plugin.statics.random() );
				},
				back: function ( col ) {
	
					$( "html" ).css( "background-color", col || plugin.statics.random() );
				},
				random: function () {
					
					return "hsl(" + Math.floor( Math.random() * 360 ) + ",95%,75%)";
				}
			},
	
			methods: {
				front: function ( col ) {
	
					return this.each( function () {
	
						$( this ).css( "color", col || plugin.statics.random() );
					} );
				},
				back: function ( col ) {
	
					return this.each( function () {
	
						$( this ).css( "background-color", col || plugin.statics.random() );
					} );
				}
			},
	
			defaultStatic: function () {
	
				return "random";
			},
	
			defaultMethod: function () {
	
				return "back";
			}
		};
	
	$.ModPlug.plugin( "color", plugin );

} )( jQuery );
